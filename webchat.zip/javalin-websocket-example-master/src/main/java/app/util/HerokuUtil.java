package app.util;

public class HerokuUtil {
    public static int getHerokuAssignedPort() {
        ProcessBuilder processBuilder = new ProcessBuilder();
        if (processBuilder.environment().get("PORT") != null) {
            return Integer.parseInt(processBuilder.environment().get("PORT"));
        }
        return 7070;
    }

	public static int getHerokuAssignedPort(String port) {
		  ProcessBuilder processBuilder = new ProcessBuilder();
	        if (processBuilder.environment().get("PORT") != null) {
	            return Integer.parseInt(processBuilder.environment().get("PORT"));
	        }
	        
	        if(port == null){
	        	return 7070;
	        }
	        return Integer.parseInt(port);
	}
}
