# javalin-websocket-example

## source code for tutorial at [https://javalin.io/tutorials/websocket-example-kotlin](https://javalin.io/tutorials/websocket-example-kotlin) 

### contains both kotlin and java source
